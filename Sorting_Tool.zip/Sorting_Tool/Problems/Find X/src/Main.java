import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        System.out.println((c - b) / a);

        /*
        a * x + b = c
        a * x = c - b
        x = (c - b) / a
         */
    }
}