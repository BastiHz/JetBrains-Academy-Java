import common.SortingToolStage1Test;

public class SortingTest extends SortingToolStage1Test {

}
